package telas;

public class ListagemUsuarios extends javax.swing.JFrame {
    public ListagemUsuarios() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fundo = new javax.swing.JPanel();
        painel = new javax.swing.JPanel();
        titulo = new javax.swing.JLabel();
        celula0_0 = new javax.swing.JLabel();
        celula0_1 = new javax.swing.JLabel();
        celula0_2 = new javax.swing.JLabel();
        celula1_0 = new javax.swing.JLabel();
        celula1_1 = new javax.swing.JLabel();
        celula1_2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Listagem de Usuários");

        fundo.setBackground(new java.awt.Color(255, 255, 255));

        painel.setBackground(new java.awt.Color(255, 255, 255));
        painel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(203, 213, 200), 1, true));

        titulo.setFont(new java.awt.Font("Arial", 1, 22)); // NOI18N
        titulo.setForeground(new java.awt.Color(37, 61, 41));
        titulo.setText("Listagem de Usuários");

        celula0_0.setBackground(new java.awt.Color(255, 255, 255));
        celula0_0.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        celula0_0.setForeground(new java.awt.Color(37, 61, 41));
        celula0_0.setText("ID Usuário");
        celula0_0.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        celula0_0.setOpaque(true);

        celula0_1.setBackground(new java.awt.Color(255, 255, 255));
        celula0_1.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        celula0_1.setForeground(new java.awt.Color(37, 61, 41));
        celula0_1.setText("Nome");
        celula0_1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        celula0_1.setOpaque(true);

        celula0_2.setBackground(new java.awt.Color(255, 255, 255));
        celula0_2.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        celula0_2.setForeground(new java.awt.Color(37, 61, 41));
        celula0_2.setText("E-mail");
        celula0_2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        celula0_2.setOpaque(true);

        celula1_0.setBackground(new java.awt.Color(255, 255, 255));
        celula1_0.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        celula1_0.setForeground(new java.awt.Color(37, 61, 41));
        celula1_0.setText("1");
        celula1_0.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        celula1_0.setOpaque(true);

        celula1_1.setBackground(new java.awt.Color(255, 255, 255));
        celula1_1.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        celula1_1.setForeground(new java.awt.Color(37, 61, 41));
        celula1_1.setText("Usuário exemplo");
        celula1_1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        celula1_1.setOpaque(true);

        celula1_2.setBackground(new java.awt.Color(255, 255, 255));
        celula1_2.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        celula1_2.setForeground(new java.awt.Color(37, 61, 41));
        celula1_2.setText("usuario@example.com");
        celula1_2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        celula1_2.setOpaque(true);

        javax.swing.GroupLayout painelLayout = new javax.swing.GroupLayout(painel);
        painel.setLayout(painelLayout);
        painelLayout.setHorizontalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 712, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(painelLayout.createSequentialGroup()
                            .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(painelLayout.createSequentialGroup()
                                    .addGap(23, 23, 23)
                                    .addComponent(celula1_0, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(painelLayout.createSequentialGroup()
                                    .addGap(143, 143, 143)
                                    .addComponent(celula1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(celula1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, painelLayout.createSequentialGroup()
                            .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(painelLayout.createSequentialGroup()
                                    .addGap(23, 23, 23)
                                    .addComponent(celula0_0, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(painelLayout.createSequentialGroup()
                                    .addGap(143, 143, 143)
                                    .addComponent(celula0_1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(celula0_2, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        painelLayout.setVerticalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(celula0_0, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(celula0_1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(celula0_2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addComponent(celula1_0, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(celula1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(celula1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(35, 35, 35))
        );

        javax.swing.GroupLayout fundoLayout = new javax.swing.GroupLayout(fundo);
        fundo.setLayout(fundoLayout);
        fundoLayout.setHorizontalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(993, Short.MAX_VALUE))
        );
        fundoLayout.setVerticalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fundoLayout.createSequentialGroup()
                .addContainerGap(187, Short.MAX_VALUE)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(210, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel celula0_0;
    private javax.swing.JLabel celula0_1;
    private javax.swing.JLabel celula0_2;
    private javax.swing.JLabel celula1_0;
    private javax.swing.JLabel celula1_1;
    private javax.swing.JLabel celula1_2;
    private javax.swing.JPanel fundo;
    private javax.swing.JPanel painel;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
