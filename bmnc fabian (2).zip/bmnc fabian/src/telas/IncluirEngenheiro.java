package telas;

/** Interface visual editável no NetBeans (sem lógica de negócio). */
public class IncluirEngenheiro extends javax.swing.JFrame {
    public IncluirEngenheiro() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fundo = new javax.swing.JPanel();
        painel = new javax.swing.JPanel();
        divisoria = new javax.swing.JPanel();
        titulo = new javax.swing.JLabel();
        rotuloNome = new javax.swing.JLabel();
        campoNome = new javax.swing.JTextField();
        rotuloCrea = new javax.swing.JLabel();
        campoCrea = new javax.swing.JTextField();
        rotuloAdmissao = new javax.swing.JLabel();
        campoAdmissao = new javax.swing.JTextField();
        cancelar = new javax.swing.JLabel();
        botaoSalvar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Incluir Engenheiro");
        setResizable(false);

        fundo.setBackground(new java.awt.Color(228, 228, 228));

        painel.setBackground(new java.awt.Color(251, 251, 251));
        painel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(203, 213, 200), 1, true));

        divisoria.setBackground(new java.awt.Color(214, 223, 211));

        titulo.setFont(new java.awt.Font("Arial", 1, 22)); // NOI18N
        titulo.setForeground(new java.awt.Color(37, 61, 41));
        titulo.setText("Incluir Engenheiro");

        rotuloNome.setForeground(new java.awt.Color(37, 61, 41));
        rotuloNome.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        rotuloNome.setText("Nome Completo");

        campoNome.setForeground(new java.awt.Color(117, 117, 117));
        campoNome.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        campoNome.setText("Ex: Carlos Eduardo Silva");
        campoNome.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(167, 182, 163), 1, true));

        rotuloCrea.setForeground(new java.awt.Color(37, 61, 41));
        rotuloCrea.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        rotuloCrea.setText("Número do CREA");

        campoCrea.setForeground(new java.awt.Color(117, 117, 117));
        campoCrea.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        campoCrea.setText("Ex: 123456/D-SP");
        campoCrea.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(167, 182, 163), 1, true));

        rotuloAdmissao.setForeground(new java.awt.Color(37, 61, 41));
        rotuloAdmissao.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        rotuloAdmissao.setText("Data de Admissão");

        campoAdmissao.setForeground(new java.awt.Color(117, 117, 117));
        campoAdmissao.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        campoAdmissao.setText("dd/mm/aaaa");
        campoAdmissao.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(167, 182, 163), 1, true));

        cancelar.setForeground(new java.awt.Color(84, 114, 82));
        cancelar.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        cancelar.setText("<html><u>Cancelar</u></html>");

        botaoSalvar.setBackground(new java.awt.Color(240, 244, 239));
        botaoSalvar.setForeground(new java.awt.Color(37, 61, 41));
        botaoSalvar.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        botaoSalvar.setText("Salvar Engenheiro");
        botaoSalvar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(167, 182, 163), 1, true));
        botaoSalvar.setOpaque(true);
        botaoSalvar.setFocusPainted(false);

        javax.swing.GroupLayout painelLayout = new javax.swing.GroupLayout(painel);
        painel.setLayout(painelLayout);
        painelLayout.setHorizontalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(rotuloNome, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(campoNome, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(rotuloCrea, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(campoCrea, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(rotuloAdmissao, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(campoAdmissao, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(113, 113, 113)
                        .addComponent(botaoSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(divisoria, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(402, 402, 402))
        );
        painelLayout.setVerticalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(divisoria, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addComponent(rotuloNome, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(111, 111, 111)
                        .addComponent(campoNome, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(157, 157, 157)
                        .addComponent(rotuloCrea, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(185, 185, 185)
                        .addComponent(campoCrea, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(231, 231, 231)
                        .addComponent(rotuloAdmissao, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(260, 260, 260)
                        .addComponent(campoAdmissao, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(326, 326, 326)
                        .addComponent(cancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(322, 322, 322)
                        .addComponent(botaoSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout fundoLayout = new javax.swing.GroupLayout(fundo);
        fundo.setLayout(fundoLayout);
        fundoLayout.setHorizontalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fundoLayout.createSequentialGroup()
                .addContainerGap(100, Short.MAX_VALUE)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(85, 85, 85))
        );
        fundoLayout.setVerticalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fundoLayout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoSalvar;
    private javax.swing.JTextField campoAdmissao;
    private javax.swing.JTextField campoCrea;
    private javax.swing.JTextField campoNome;
    private javax.swing.JLabel cancelar;
    private javax.swing.JPanel divisoria;
    private javax.swing.JPanel fundo;
    private javax.swing.JPanel painel;
    private javax.swing.JLabel rotuloAdmissao;
    private javax.swing.JLabel rotuloCrea;
    private javax.swing.JLabel rotuloNome;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
