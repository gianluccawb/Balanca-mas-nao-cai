package telas;

public class AcessoSistema extends javax.swing.JFrame {
    public AcessoSistema() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fundo = new javax.swing.JPanel();
        painel = new javax.swing.JPanel();
        dicaUsuario = new javax.swing.JLabel();
        dicaSenha = new javax.swing.JLabel();
        marca = new javax.swing.JLabel();
        titulo = new javax.swing.JLabel();
        rotuloUsuario = new javax.swing.JLabel();
        campoUsuario = new javax.swing.JTextField();
        rotuloSenha = new javax.swing.JLabel();
        campoSenha = new javax.swing.JPasswordField();
        botaoEntrar = new javax.swing.JButton();
        botaoApagar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Acesso ao Sistema");

        fundo.setBackground(new java.awt.Color(255, 255, 255));

        painel.setBackground(new java.awt.Color(255, 255, 255));
        painel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(203, 213, 200), 1, true));

        dicaUsuario.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        dicaUsuario.setForeground(new java.awt.Color(117, 117, 117));
        dicaUsuario.setText("Seu melhor e-mail");

        dicaSenha.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        dicaSenha.setForeground(new java.awt.Color(117, 117, 117));
        dicaSenha.setText("Sua senha");

        marca.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        marca.setForeground(new java.awt.Color(37, 61, 41));
        marca.setText("Balança Mas Não Cai");

        titulo.setFont(new java.awt.Font("Arial", 0, 22)); // NOI18N
        titulo.setForeground(new java.awt.Color(37, 61, 41));
        titulo.setText("Acesso ao Sistema");

        rotuloUsuario.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        rotuloUsuario.setForeground(new java.awt.Color(37, 61, 41));
        rotuloUsuario.setText("Usuário");

        campoUsuario.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        campoUsuario.setForeground(new java.awt.Color(37, 61, 41));
        campoUsuario.setToolTipText("Seu melhor e-mail");
        campoUsuario.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(167, 182, 163), 1, true));

        rotuloSenha.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        rotuloSenha.setForeground(new java.awt.Color(37, 61, 41));
        rotuloSenha.setText("Senha");

        campoSenha.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        campoSenha.setForeground(new java.awt.Color(37, 61, 41));
        campoSenha.setToolTipText("Sua senha");
        campoSenha.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(167, 182, 163), 1, true));

        botaoEntrar.setBackground(new java.awt.Color(240, 244, 239));
        botaoEntrar.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        botaoEntrar.setForeground(new java.awt.Color(37, 61, 41));
        botaoEntrar.setText("Entrar");
        botaoEntrar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(167, 182, 163), 1, true));
        botaoEntrar.setFocusPainted(false);
        botaoEntrar.setOpaque(true);

        botaoApagar.setBackground(new java.awt.Color(240, 244, 239));
        botaoApagar.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        botaoApagar.setForeground(new java.awt.Color(37, 61, 41));
        botaoApagar.setText("Apagar");
        botaoApagar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(167, 182, 163), 1, true));
        botaoApagar.setFocusPainted(false);
        botaoApagar.setOpaque(true);

        javax.swing.GroupLayout painelLayout = new javax.swing.GroupLayout(painel);
        painel.setLayout(painelLayout);
        painelLayout.setHorizontalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(dicaUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(dicaSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(marca, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(rotuloUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(campoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(rotuloSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(campoSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(botaoEntrar, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addComponent(botaoApagar, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(22, 22, 22))
        );
        painelLayout.setVerticalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(marca, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addComponent(dicaUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(181, 181, 181)
                        .addComponent(dicaSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(rotuloUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addComponent(campoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(152, 152, 152)
                        .addComponent(rotuloSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(180, 180, 180)
                        .addComponent(campoSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(231, 231, 231)
                        .addComponent(botaoEntrar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(231, 231, 231)
                        .addComponent(botaoApagar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(80, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout fundoLayout = new javax.swing.GroupLayout(fundo);
        fundo.setLayout(fundoLayout);
        fundoLayout.setHorizontalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fundoLayout.createSequentialGroup()
                .addContainerGap(78, Short.MAX_VALUE)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(104, 104, 104))
        );
        fundoLayout.setVerticalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoLayout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoApagar;
    private javax.swing.JButton botaoEntrar;
    private javax.swing.JPasswordField campoSenha;
    private javax.swing.JTextField campoUsuario;
    private javax.swing.JLabel dicaSenha;
    private javax.swing.JLabel dicaUsuario;
    private javax.swing.JPanel fundo;
    private javax.swing.JLabel marca;
    private javax.swing.JPanel painel;
    private javax.swing.JLabel rotuloSenha;
    private javax.swing.JLabel rotuloUsuario;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
