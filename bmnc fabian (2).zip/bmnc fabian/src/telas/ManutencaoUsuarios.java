package telas;

public class ManutencaoUsuarios extends javax.swing.JFrame {
    public ManutencaoUsuarios() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fundo = new javax.swing.JPanel();
        painel = new javax.swing.JPanel();
        titulo = new javax.swing.JLabel();
        botaoIncluir = new javax.swing.JButton();
        botaoConsultar = new javax.swing.JButton();
        botaoAlterar = new javax.swing.JButton();
        botaoExcluir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Manutenção de Usuários");

        fundo.setBackground(new java.awt.Color(255, 255, 255));

        painel.setBackground(new java.awt.Color(255, 255, 255));
        painel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(203, 213, 200), 1, true));

        titulo.setFont(new java.awt.Font("Arial", 0, 22)); // NOI18N
        titulo.setForeground(new java.awt.Color(37, 61, 41));
        titulo.setText("Manutenção de Usuários");

        botaoIncluir.setBackground(new java.awt.Color(240, 244, 239));
        botaoIncluir.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        botaoIncluir.setForeground(new java.awt.Color(37, 61, 41));
        botaoIncluir.setText("Inclusão");
        botaoIncluir.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        botaoIncluir.setFocusPainted(false);
        botaoIncluir.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        botaoIncluir.setMargin(new java.awt.Insets(0, 13, 0, 0));
        botaoIncluir.setOpaque(true);

        botaoConsultar.setBackground(new java.awt.Color(240, 244, 239));
        botaoConsultar.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        botaoConsultar.setForeground(new java.awt.Color(37, 61, 41));
        botaoConsultar.setText("Consulta");
        botaoConsultar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        botaoConsultar.setFocusPainted(false);
        botaoConsultar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        botaoConsultar.setMargin(new java.awt.Insets(0, 13, 0, 0));
        botaoConsultar.setOpaque(true);

        botaoAlterar.setBackground(new java.awt.Color(240, 244, 239));
        botaoAlterar.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        botaoAlterar.setForeground(new java.awt.Color(37, 61, 41));
        botaoAlterar.setText("Alteração");
        botaoAlterar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        botaoAlterar.setFocusPainted(false);
        botaoAlterar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        botaoAlterar.setMargin(new java.awt.Insets(0, 13, 0, 0));
        botaoAlterar.setOpaque(true);

        botaoExcluir.setBackground(new java.awt.Color(240, 244, 239));
        botaoExcluir.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        botaoExcluir.setForeground(new java.awt.Color(37, 61, 41));
        botaoExcluir.setText("Exclusão");
        botaoExcluir.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        botaoExcluir.setFocusPainted(false);
        botaoExcluir.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        botaoExcluir.setMargin(new java.awt.Insets(0, 13, 0, 0));
        botaoExcluir.setOpaque(true);

        javax.swing.GroupLayout painelLayout = new javax.swing.GroupLayout(painel);
        painel.setLayout(painelLayout);
        painelLayout.setHorizontalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(titulo, javax.swing.GroupLayout.DEFAULT_SIZE, 314, Short.MAX_VALUE)
                    .addComponent(botaoExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botaoAlterar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botaoConsultar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botaoIncluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(22, 22, 22))
        );
        painelLayout.setVerticalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(botaoIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botaoConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botaoAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botaoExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout fundoLayout = new javax.swing.GroupLayout(fundo);
        fundo.setLayout(fundoLayout);
        fundoLayout.setHorizontalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fundoLayout.createSequentialGroup()
                .addContainerGap(115, Short.MAX_VALUE)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(104, 104, 104))
        );
        fundoLayout.setVerticalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoLayout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(83, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoAlterar;
    private javax.swing.JButton botaoConsultar;
    private javax.swing.JButton botaoExcluir;
    private javax.swing.JButton botaoIncluir;
    private javax.swing.JPanel fundo;
    private javax.swing.JPanel painel;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
