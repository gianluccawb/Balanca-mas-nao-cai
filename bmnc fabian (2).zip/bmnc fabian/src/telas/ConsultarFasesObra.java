package telas;

/** Interface visual editável no NetBeans (sem lógica de negócio). */
public class ConsultarFasesObra extends javax.swing.JFrame {
    public ConsultarFasesObra() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fundo = new javax.swing.JPanel();
        painel = new javax.swing.JPanel();
        titulo = new javax.swing.JLabel();
        cabCodigo = new javax.swing.JLabel();
        cabDescricao = new javax.swing.JLabel();
        cod1 = new javax.swing.JLabel();
        desc1 = new javax.swing.JLabel();
        cod2 = new javax.swing.JLabel();
        desc2 = new javax.swing.JLabel();
        cod3 = new javax.swing.JLabel();
        desc3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Consulta Fases da Obra");
        setResizable(false);

        fundo.setBackground(new java.awt.Color(255, 255, 255));

        painel.setBackground(new java.awt.Color(251, 251, 251));
        painel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(203, 213, 200), 1, true));

        titulo.setFont(new java.awt.Font("Arial", 1, 22)); // NOI18N
        titulo.setForeground(new java.awt.Color(37, 61, 41));
        titulo.setText("Consulta Fases da Obra");

        cabCodigo.setBackground(new java.awt.Color(255, 255, 255));
        cabCodigo.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        cabCodigo.setForeground(new java.awt.Color(82, 99, 79));
        cabCodigo.setText("Código");
        cabCodigo.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        cabCodigo.setOpaque(true);

        cabDescricao.setBackground(new java.awt.Color(255, 255, 255));
        cabDescricao.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        cabDescricao.setForeground(new java.awt.Color(82, 99, 79));
        cabDescricao.setText("Descrição da Fase");
        cabDescricao.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        cabDescricao.setOpaque(true);

        cod1.setBackground(new java.awt.Color(251, 251, 251));
        cod1.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        cod1.setForeground(new java.awt.Color(82, 99, 79));
        cod1.setText("  1");
        cod1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        cod1.setOpaque(true);

        desc1.setBackground(new java.awt.Color(251, 251, 251));
        desc1.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        desc1.setForeground(new java.awt.Color(82, 99, 79));
        desc1.setText("  Fundações");
        desc1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        desc1.setOpaque(true);

        cod2.setBackground(new java.awt.Color(251, 251, 251));
        cod2.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        cod2.setForeground(new java.awt.Color(82, 99, 79));
        cod2.setText("  2");
        cod2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        cod2.setOpaque(true);

        desc2.setBackground(new java.awt.Color(251, 251, 251));
        desc2.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        desc2.setForeground(new java.awt.Color(82, 99, 79));
        desc2.setText("  Estrutura");
        desc2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        desc2.setOpaque(true);

        cod3.setBackground(new java.awt.Color(251, 251, 251));
        cod3.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        cod3.setForeground(new java.awt.Color(82, 99, 79));
        cod3.setText("  3");
        cod3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        cod3.setOpaque(true);

        desc3.setBackground(new java.awt.Color(251, 251, 251));
        desc3.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        desc3.setForeground(new java.awt.Color(82, 99, 79));
        desc3.setText("  Pintura");
        desc3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        desc3.setOpaque(true);

        javax.swing.GroupLayout painelLayout = new javax.swing.GroupLayout(painel);
        painel.setLayout(painelLayout);
        painelLayout.setHorizontalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(cabCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addComponent(cabDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 539, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(cod1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addComponent(desc1, javax.swing.GroupLayout.PREFERRED_SIZE, 539, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(cod2, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addComponent(desc2, javax.swing.GroupLayout.PREFERRED_SIZE, 539, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(cod3, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addComponent(desc3, javax.swing.GroupLayout.PREFERRED_SIZE, 539, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(23, 23, 23))
        );
        painelLayout.setVerticalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(115, 115, 115)
                .addComponent(cabCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(115, 115, 115)
                .addComponent(cabDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(158, 158, 158)
                .addComponent(cod1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(158, 158, 158)
                .addComponent(desc1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(207, 207, 207)
                .addComponent(cod2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(207, 207, 207)
                .addComponent(desc2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(256, 256, 256)
                .addComponent(cod3, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(256, 256, 256)
                .addComponent(desc3, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout fundoLayout = new javax.swing.GroupLayout(fundo);
        fundo.setLayout(fundoLayout);
        fundoLayout.setHorizontalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, 690, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );
        fundoLayout.setVerticalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fundoLayout.createSequentialGroup()
                .addContainerGap(71, Short.MAX_VALUE)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel cabCodigo;
    private javax.swing.JLabel cabDescricao;
    private javax.swing.JLabel cod1;
    private javax.swing.JLabel cod2;
    private javax.swing.JLabel cod3;
    private javax.swing.JLabel desc1;
    private javax.swing.JLabel desc2;
    private javax.swing.JLabel desc3;
    private javax.swing.JPanel fundo;
    private javax.swing.JPanel painel;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
