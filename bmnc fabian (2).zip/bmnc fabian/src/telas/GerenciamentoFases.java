package telas;

public class GerenciamentoFases extends javax.swing.JFrame {
    public GerenciamentoFases() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fundo = new javax.swing.JPanel();
        painel = new javax.swing.JPanel();
        modulo = new javax.swing.JLabel();
        divisoria = new javax.swing.JPanel();
        botaoIncluir = new javax.swing.JButton();
        botaoConsultar = new javax.swing.JButton();
        botaoAlterar = new javax.swing.JButton();
        botaoExcluir = new javax.swing.JButton();
        titulo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gerenciamento da Fase da Obra");

        fundo.setBackground(new java.awt.Color(228, 228, 228));

        painel.setBackground(new java.awt.Color(255, 255, 255));
        painel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(203, 213, 200), 1, true));

        modulo.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        modulo.setForeground(new java.awt.Color(37, 61, 41));
        modulo.setText("Fase da Obra");

        divisoria.setBackground(new java.awt.Color(214, 223, 211));

        botaoIncluir.setBackground(new java.awt.Color(240, 244, 239));
        botaoIncluir.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        botaoIncluir.setForeground(new java.awt.Color(37, 61, 41));
        botaoIncluir.setText("Inclui Fase");
        botaoIncluir.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        botaoIncluir.setFocusPainted(false);
        botaoIncluir.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        botaoIncluir.setMargin(new java.awt.Insets(0, 13, 0, 0));
        botaoIncluir.setOpaque(true);

        botaoConsultar.setBackground(new java.awt.Color(240, 244, 239));
        botaoConsultar.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        botaoConsultar.setForeground(new java.awt.Color(37, 61, 41));
        botaoConsultar.setText("Consulta Fase");
        botaoConsultar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        botaoConsultar.setFocusPainted(false);
        botaoConsultar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        botaoConsultar.setMargin(new java.awt.Insets(0, 13, 0, 0));
        botaoConsultar.setOpaque(true);

        botaoAlterar.setBackground(new java.awt.Color(240, 244, 239));
        botaoAlterar.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        botaoAlterar.setForeground(new java.awt.Color(37, 61, 41));
        botaoAlterar.setText("Altera Fase");
        botaoAlterar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        botaoAlterar.setFocusPainted(false);
        botaoAlterar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        botaoAlterar.setMargin(new java.awt.Insets(0, 13, 0, 0));
        botaoAlterar.setOpaque(true);

        botaoExcluir.setBackground(new java.awt.Color(240, 244, 239));
        botaoExcluir.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        botaoExcluir.setForeground(new java.awt.Color(37, 61, 41));
        botaoExcluir.setText("Exclui Fase");
        botaoExcluir.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 223, 211), 1, true));
        botaoExcluir.setFocusPainted(false);
        botaoExcluir.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        botaoExcluir.setMargin(new java.awt.Insets(0, 13, 0, 0));
        botaoExcluir.setOpaque(true);

        titulo.setFont(new java.awt.Font("Arial", 0, 22)); // NOI18N
        titulo.setForeground(new java.awt.Color(37, 61, 41));
        titulo.setText("Gerenciamento da Fase da Obra");

        javax.swing.GroupLayout painelLayout = new javax.swing.GroupLayout(painel);
        painel.setLayout(painelLayout);
        painelLayout.setHorizontalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(modulo, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(divisoria, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botaoIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botaoConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botaoAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botaoExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(15, 15, 15))
        );
        painelLayout.setVerticalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(modulo, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(divisoria, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(12, 12, 12)
                .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(botaoIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(botaoConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(129, 129, 129)
                        .addComponent(botaoAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(183, 183, 183)
                        .addComponent(botaoExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(39, 39, 39))
        );

        javax.swing.GroupLayout fundoLayout = new javax.swing.GroupLayout(fundo);
        fundo.setLayout(fundoLayout);
        fundoLayout.setHorizontalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoLayout.createSequentialGroup()
                .addGap(143, 143, 143)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(426, Short.MAX_VALUE))
        );
        fundoLayout.setVerticalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(183, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoAlterar;
    private javax.swing.JButton botaoConsultar;
    private javax.swing.JButton botaoExcluir;
    private javax.swing.JButton botaoIncluir;
    private javax.swing.JPanel divisoria;
    private javax.swing.JPanel fundo;
    private javax.swing.JLabel modulo;
    private javax.swing.JPanel painel;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
