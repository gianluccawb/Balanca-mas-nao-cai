package telas;

/** Interface visual editável no NetBeans (sem lógica de negócio). */
public class IncluirFaseObra extends javax.swing.JFrame {
    public IncluirFaseObra() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fundo = new javax.swing.JPanel();
        painel = new javax.swing.JPanel();
        titulo = new javax.swing.JLabel();
        voltar = new javax.swing.JLabel();
        rotuloDescricao = new javax.swing.JLabel();
        campoDescricao = new javax.swing.JTextField();
        botaoIncluir = new javax.swing.JButton();
        botaoLimpar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Inclusão de Fase da Obra");
        setResizable(false);

        fundo.setBackground(new java.awt.Color(228, 228, 228));

        painel.setBackground(new java.awt.Color(251, 251, 251));
        painel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(203, 213, 200), 1, true));

        titulo.setForeground(new java.awt.Color(37, 61, 41));
        titulo.setFont(new java.awt.Font("Arial", 1, 22)); // NOI18N
        titulo.setText("Inclusão de Fase da Obra");

        voltar.setForeground(new java.awt.Color(84, 114, 82));
        voltar.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        voltar.setText("<html><u>← Voltar</u></html>");

        rotuloDescricao.setForeground(new java.awt.Color(37, 61, 41));
        rotuloDescricao.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        rotuloDescricao.setText("Descrição da Fase");

        campoDescricao.setForeground(new java.awt.Color(117, 117, 117));
        campoDescricao.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        campoDescricao.setText("Ex: Fundações, Estrutura, Pintura");
        campoDescricao.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(167, 182, 163), 1, true));

        botaoIncluir.setBackground(new java.awt.Color(240, 244, 239));
        botaoIncluir.setForeground(new java.awt.Color(37, 61, 41));
        botaoIncluir.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        botaoIncluir.setText("Incluir Fase");
        botaoIncluir.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(167, 182, 163), 1, true));
        botaoIncluir.setOpaque(true);
        botaoIncluir.setFocusPainted(false);

        botaoLimpar.setBackground(new java.awt.Color(240, 244, 239));
        botaoLimpar.setForeground(new java.awt.Color(37, 61, 41));
        botaoLimpar.setFont(new java.awt.Font("Arial", 0, 15)); // NOI18N
        botaoLimpar.setText("Limpar");
        botaoLimpar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(167, 182, 163), 1, true));
        botaoLimpar.setOpaque(true);
        botaoLimpar.setFocusPainted(false);

        javax.swing.GroupLayout painelLayout = new javax.swing.GroupLayout(painel);
        painel.setLayout(painelLayout);
        painelLayout.setHorizontalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(voltar, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(rotuloDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(campoDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(botaoIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(157, 157, 157)
                        .addComponent(botaoLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(25, 25, 25))
        );
        painelLayout.setVerticalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(voltar, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(115, 115, 115)
                .addComponent(rotuloDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(143, 143, 143)
                .addComponent(campoDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(195, 195, 195)
                .addComponent(botaoIncluir, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(painelLayout.createSequentialGroup()
                .addGap(195, 195, 195)
                .addComponent(botaoLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout fundoLayout = new javax.swing.GroupLayout(fundo);
        fundo.setLayout(fundoLayout);
        fundoLayout.setHorizontalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoLayout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(109, Short.MAX_VALUE))
        );
        fundoLayout.setVerticalGroup(
            fundoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fundoLayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(painel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(109, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(fundo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoIncluir;
    private javax.swing.JButton botaoLimpar;
    private javax.swing.JTextField campoDescricao;
    private javax.swing.JPanel fundo;
    private javax.swing.JPanel painel;
    private javax.swing.JLabel rotuloDescricao;
    private javax.swing.JLabel titulo;
    private javax.swing.JLabel voltar;
    // End of variables declaration//GEN-END:variables
}
